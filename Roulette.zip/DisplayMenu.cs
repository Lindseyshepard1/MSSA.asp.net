﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette
{
    class DisplayMenu
    {
        public void InitialDisplay()
        {
            Console.WriteLine("I am your screen");
            Console.WriteLine("");
            Console.WriteLine("");
 
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("                                              Welcome to Roulette!");
            Console.WriteLine("                                You have $100 to start, will you win or lose?");
            Console.WriteLine("");
            Console.WriteLine("                                           Press Enter to begin...");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("                                             2019 - Lindsey Shepard");
            Console.ReadLine();
            Console.Clear();

        }
    }
}
